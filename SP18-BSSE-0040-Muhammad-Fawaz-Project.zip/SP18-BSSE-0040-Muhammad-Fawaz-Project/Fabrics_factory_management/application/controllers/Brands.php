<?php
		
		require_once "application/core/AdminController.php";
		class Brands extends AdminController{

			function __construct(){
				parent::__construct();
				$this->load->model("Brands_model","brands"); 
				$this->load->model("Product_model","products"); 
			}
			
			function index(){
				$data["brands"] = $this->brands->read();
				$this->load->view("brands/view",$data);
			}
			
			function add(){
				$this->load->view("brands/add");
			}
			
			function save(){
				
				$this->form_validation->set_rules("name","Name","required");
				
				if($this->form_validation->run()==TRUE){
				
				$data=array(
					"BrandName"		=> 	$_POST["name"]
				);

				$result = $this->brands->save($data);
					
				
					if($result){
						$this->session->set_flashdata("success_msg", "Brands Added Successfully!");
						redirect(base_url("brands"));
					}	
				}
			
				else{
					$this->add();
				}
			}
		
			
			function delete($id){
				
				
					$msg = "Data Deleted Successfully!";
					$msg_type = "success_msg";
					$this->brands->delete($id);
				
				                        
				$this->session->set_flashdata($msg_type, $msg);
				redirect(base_url("brands"));
			}
			
				
			function edit($id){
				$data['brand'] = $this->brands->select($id);
				$this->load->view("brands/edit",$data);
			}

			
			function update($id){
				
				$this->form_validation->set_rules("name","Name","required");
				
				if($this->form_validation->run()==TRUE){
				
				$data=array(
					"BrandName"		=> 	$_POST["name"]
				);
			
				$result = $this->brands->update($id,$data);
				if($result){
					$this->session->set_flashdata("success_msg", "Brands Updated Successfully!");
					redirect(base_url("brands"));
				}	
			}
			
			else{
				$this->edit($id);
			}
			
		}
		
			
	}	
?>