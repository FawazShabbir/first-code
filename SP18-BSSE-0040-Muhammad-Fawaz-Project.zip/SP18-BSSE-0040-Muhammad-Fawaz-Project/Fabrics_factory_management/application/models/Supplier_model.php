<?php
	
	class Supplier_model extends CI_MODEL{
		
		function read(){
			$result = $this->db->get("suppliers");
			return $result->result_array();
		}
		
		function select($id){
			$this->db->where("SupplierID",$id);
			$result = $this->db->get("suppliers");
			return $result->result_array();
		}
	
		function save($data){
			$result = $this->db->insert("suppliers",$data);
			return $result;
		}
		
		function delete($id){
			$this->db->where("SupplierID",$id);
			$result = $this->db->delete("suppliers");
			return $this->db->error();
		}
		
		function update($id,$data){
			$this->db->where("SupplierID",$id);
			$result = $this->db->update("suppliers",$data);
			return $result;
		}
		
	}

?>
