-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2021 at 11:27 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fabrics_factory`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `BrandID` int(11) NOT NULL,
  `BrandName` varchar(50) NOT NULL,
  `DateAdded` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DateModified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`BrandID`, `BrandName`, `DateAdded`, `DateModified`) VALUES
(10, 'CHINA', '2020-05-30 21:38:19', '0000-00-00 00:00:00'),
(11, 'JAPAN', '2020-05-30 21:38:26', '0000-00-00 00:00:00'),
(12, 'LOCAL', '2020-05-30 21:38:34', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `chemicals`
--

CREATE TABLE `chemicals` (
  `ChemicalID` int(11) NOT NULL,
  `ChemicalName` varchar(50) NOT NULL,
  `DateAdded` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DateModified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chemicals`
--

INSERT INTO `chemicals` (`ChemicalID`, `ChemicalName`, `DateAdded`, `DateModified`) VALUES
(3, 'LEVLAR', '2020-05-29 10:30:33', '0000-00-00 00:00:00'),
(4, 'SOFTNER', '2020-05-29 10:30:42', '0000-00-00 00:00:00'),
(6, 'BUFFER', '2020-05-29 10:30:58', '0000-00-00 00:00:00'),
(7, 'SEQUESTOR', '2020-05-29 10:31:10', '0000-00-00 00:00:00'),
(8, 'RC', '2020-05-31 12:09:55', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `colours`
--

CREATE TABLE `colours` (
  `ColourID` int(11) NOT NULL,
  `ColourName` varchar(50) NOT NULL,
  `DateAdded` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DateModified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `colours`
--

INSERT INTO `colours` (`ColourID`, `ColourName`, `DateAdded`, `DateModified`) VALUES
(8, 'YELLOW', '2020-05-30 19:47:09', '0000-00-00 00:00:00'),
(14, 'BLUE', '2020-05-30 19:47:14', '0000-00-00 00:00:00'),
(18, 'BLACK', '2020-05-30 19:47:18', '0000-00-00 00:00:00'),
(21, 'RED', '2020-05-30 19:47:04', '0000-00-00 00:00:00'),
(23, 'WHITE', '2020-05-29 10:40:28', '0000-00-00 00:00:00'),
(24, 'DYED', '2020-05-29 10:41:13', '0000-00-00 00:00:00'),
(25, 'BLACK', '2020-05-29 10:41:21', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `labour`
--

CREATE TABLE `labour` (
  `LabourID` int(11) NOT NULL,
  `LabourName` varchar(30) NOT NULL,
  `DateAdded` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `DateModified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `labour`
--

INSERT INTO `labour` (`LabourID`, `LabourName`, `DateAdded`, `DateModified`) VALUES
(5, 'Haider', '2020-05-29 19:49:19', '0000-00-00 00:00:00'),
(6, 'FAISAL', '2020-05-29 19:49:31', '0000-00-00 00:00:00'),
(8, 'MATEEN', '2020-05-29 19:49:45', '0000-00-00 00:00:00'),
(9, 'IRFAN', '2020-05-29 19:49:58', '0000-00-00 00:00:00'),
(10, 'Ali', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ProductID` int(11) NOT NULL,
  `ProductName` varchar(80) NOT NULL,
  `ProductCategory` varchar(10) NOT NULL,
  `DateAdded` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DateModified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Date` varchar(15) NOT NULL,
  `Year` int(11) NOT NULL,
  `Month` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ProductID`, `ProductName`, `ProductCategory`, `DateAdded`, `DateModified`, `Date`, `Year`, `Month`) VALUES
(28, 'DYES', 'dyes', '2020-05-30 10:39:26', '0000-00-00 00:00:00', '09-Sep-19', 2019, 9),
(29, 'CHEMICAL', 'chemical', '2020-05-30 10:39:40', '0000-00-00 00:00:00', '09-Sep-19', 2019, 9),
(30, 'THREAD', 'other', '2020-05-30 10:52:34', '0000-00-00 00:00:00', '09-Sep-19', 2019, 9),
(42, 'Paint', 'other', '2020-05-31 09:49:06', '0000-00-00 00:00:00', '31-May-20', 2020, 5);

-- --------------------------------------------------------

--
-- Table structure for table `purchasing`
--

CREATE TABLE `purchasing` (
  `PurchaseID` int(11) NOT NULL,
  `Date` varchar(15) NOT NULL,
  `SupplierID` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `BrandID` int(11) NOT NULL,
  `UnitID` int(11) NOT NULL,
  `Qtyinkg` double NOT NULL,
  `ColourID` int(11) DEFAULT NULL,
  `ChemicalID` int(11) DEFAULT NULL,
  `Rate` double NOT NULL,
  `Amount` double NOT NULL,
  `Description` text NOT NULL,
  `Year` int(11) NOT NULL,
  `Month` int(11) NOT NULL,
  `DateAdded` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DateModified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchasing`
--

INSERT INTO `purchasing` (`PurchaseID`, `Date`, `SupplierID`, `ProductID`, `BrandID`, `UnitID`, `Qtyinkg`, `ColourID`, `ChemicalID`, `Rate`, `Amount`, `Description`, `Year`, `Month`, `DateAdded`, `DateModified`) VALUES
(91, '2020-05-20', 3, 29, 6, 5, 5000000, NULL, 3, 20, 100000, '					', 2020, 5, '2020-05-30 20:03:57', '0000-00-00 00:00:00'),
(92, '2020-05-20', 3, 29, 6, 5, 5000000, NULL, 3, 20, 100000, '					', 2020, 5, '2020-05-30 20:03:57', '0000-00-00 00:00:00'),
(93, '2020-05-09', 3, 28, 8, 6, 5000000, 21, NULL, 100, 500000, '					', 2020, 5, '2020-05-30 20:27:30', '0000-00-00 00:00:00'),
(95, '2020-05-09', 3, 28, 8, 6, 50000, 21, 0, 100, 50000, '', 2020, 5, '2020-05-28 20:26:00', '0000-00-00 00:00:00'),
(96, '2020-05-29', 3, 28, 8, 6, 50000, 21, NULL, 100, 50000, '', 2020, 5, '2020-05-31 13:03:21', '0000-00-00 00:00:00'),
(97, '2020-05-29', 3, 29, 7, 6, 50000, 22, NULL, 100, 50000, '', 2020, 5, '2020-05-31 13:05:45', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `SupplierID` int(11) NOT NULL,
  `SupplierName` varchar(100) NOT NULL,
  `DateAdded` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DateModified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`SupplierID`, `SupplierName`, `DateAdded`, `DateModified`) VALUES
(3, 'SWISS CHEMICAL & DYES', '2020-05-30 10:49:12', '0000-00-00 00:00:00'),
(4, 'MEHMOOD BROTHERS', '2020-05-30 10:49:22', '0000-00-00 00:00:00'),
(6, 'Ahmed and Co.', '2020-05-31 13:28:55', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `UnitID` int(11) NOT NULL,
  `UnitName` varchar(50) NOT NULL,
  `DateAdded` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DateModified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`UnitID`, `UnitName`, `DateAdded`, `DateModified`) VALUES
(4, 'KG', '2020-05-30 10:38:47', '0000-00-00 00:00:00'),
(5, 'GRAM', '2020-05-30 10:38:57', '0000-00-00 00:00:00'),
(6, 'PCS', '2020-05-30 10:39:03', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(150) NOT NULL,
  `DateAdded` timestamp NOT NULL DEFAULT current_timestamp(),
  `DateModified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `Username`, `Password`, `DateAdded`, `DateModified`) VALUES
(1, 'admin', 'admin', '2021-06-15 19:34:28', '0000-00-00 00:00:00'),
(2, 'admin', 'QVgMGaQQbGmaUQAsYgL4dnpAkta6K/or88UsiHfZMNoCds9dXYnsvAiVzpHIxQN+aXdWJZY5vfjakcqPN9Rumw==', '2020-05-18 15:05:00', '2020-05-30 21:45:19'),
(3, 'admin', 'admin', '2021-06-15 19:34:06', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`BrandID`);

--
-- Indexes for table `chemicals`
--
ALTER TABLE `chemicals`
  ADD PRIMARY KEY (`ChemicalID`);

--
-- Indexes for table `colours`
--
ALTER TABLE `colours`
  ADD PRIMARY KEY (`ColourID`);

--
-- Indexes for table `labour`
--
ALTER TABLE `labour`
  ADD PRIMARY KEY (`LabourID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ProductID`);

--
-- Indexes for table `purchasing`
--
ALTER TABLE `purchasing`
  ADD PRIMARY KEY (`PurchaseID`),
  ADD KEY `ColourID` (`ColourID`),
  ADD KEY `ChemicalID` (`ChemicalID`),
  ADD KEY `BrandID` (`BrandID`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`SupplierID`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`UnitID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `BrandID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `chemicals`
--
ALTER TABLE `chemicals`
  MODIFY `ChemicalID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `colours`
--
ALTER TABLE `colours`
  MODIFY `ColourID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `labour`
--
ALTER TABLE `labour`
  MODIFY `LabourID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `purchasing`
--
ALTER TABLE `purchasing`
  MODIFY `PurchaseID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `SupplierID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `UnitID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
