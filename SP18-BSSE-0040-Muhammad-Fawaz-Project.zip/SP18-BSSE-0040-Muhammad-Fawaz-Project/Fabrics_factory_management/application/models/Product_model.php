<?php 

class Product_model extends CI_Model {

		function read(){
		    $result = $this->db->get("products");
		   	return $result->result_array();
		}
		
		
		
		
		function read_by_category($category){
			$this->db->where("ProductCategory",$category);
			$result = $this->db->get("products");
			return $result->result_array();
		}
		
		function select($id){
			$this->db->where("ProductID",$id);
			$result = $this->db->get("products");
			return $result->result_array();
		}
	
		function save($data){
			$this->db->insert("products",$data);
			$insert_id = $this->db->insert_id();
			return $insert_id;
		}
		
		function delete($id){
			$this->db->where("ProductID",$id);
			$this->db->delete("products");
			return $this->db->error();
		}
		
		function update($id,$data){
			$this->db->where("ProductID",$id);
			$result = $this->db->update("products",$data);
			return $result;
		}

        
        
		
		
		/* Insert Data in Products_Brands Bridge Tables */
		function save_product_brands($data){
			$result = $this->db->insert_batch("product_brands",$data);
			return $result;
		}
		
		/* Insert Data in Products_colorus Bridge Tables */
		function save_product_colours($data){
			$result = $this->db->insert_batch("product_color",$data);
			return $result;
		}
		
		/* Insert Data in Products_chemicals Bridge Tables */
		function save_product_chemicals($data){
			$result = $this->db->insert_batch("product_chemicals",$data);
			return $result;
		}
		
		
		function read_colours(){
			$result = $this->db->get("colours");
			return $result->result_array();
		}
		
		function read_chemicals(){
			$result = $this->db->get("chemicals");
			return $result->result_array();
		}
		
		/* Read Brands Related to Product (ProductID) */
		function brands_of_products($productID){
			$result = $this->db->query("Select * from product_brands left join brands 
			on product_brands.BrandID = brands.BrandID where productID = ".$productID);
			return $result->result_array();
		}
		
		/* Read Colours Related to Product (ProductID) */
		function colors_of_products($productID){
			$result = $this->db->query("Select * from product_color left join colours
			on product_color.ColourID = colours.ColourID where productID = ".$productID);
			return $result->result_array();
		}
		
		/* Read Chemicals Related to Product (ProductID) */
		function chemicals_of_products($productID){
			$result = $this->db->query("Select * from product_chemicals left join chemicals
			on product_chemicals.ChemicalID = chemicals.ChemicalID where productID = ".$productID);
			return $result->result_array();
		}
		
		/* Delete function for Chemicals,Colours,Brands */
		function delete_specific($table_name,$productid){
			$this->db->where("ProductID",$productid);
			$result = $this->db->delete($table_name);
			return $result;
		}
		
		function read_units(){
			$result = $this->db->get("units");
			return $result->result_array();
		}
		
}
	

?>