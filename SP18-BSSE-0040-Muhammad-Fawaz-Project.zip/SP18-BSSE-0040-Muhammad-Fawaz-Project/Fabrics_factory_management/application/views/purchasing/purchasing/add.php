
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin | Add Purchase / Recieve</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/Ionicons/css/ionicons.min.css">
  <!-- daterange picker -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/bootstrap-daterangepicker/daterangepicker.css">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>plugins/iCheck/all.css">
  <!-- Bootstrap Color Picker -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css">
  <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>plugins/timepicker/bootstrap-timepicker.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?= include(APPPATH."views/includes/header.php"); ?>
  <?= include(APPPATH."views/includes/sidebar.php"); ?>
  
  
  
  <!-- Content Wrapper. Contains page content -->
  
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Add Purchase / Recieve
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Purchase / Recieve</a></li>
        <li class="active">Purchase / Recieve</li>
      </ol>
    </section>

	<!-- Purchasing Start -->
	
    <!-- Main content -->
    <section class="content">
	<div class="row">
		<div class="col-lg-6">
			<button type="button" id="btn_purchase" class="btn btn-success">Purchase</button>
			<button type="button" id="btn_recieve" class="btn btn-info">Recieve</button>
		</div> 
		
		<div class="col-lg-6">
		</div>
		
	</div>
	<br>
	<?php 	$error_check = $this->session->flashdata("recieve_error"); ?>
	<div id="purchasing_box" style="display:<?= ($error_check == "0" ? "block" : "none")?>">
	<form method="post" action="<?= base_url("purchasing/save")?>">
      <!-- SELECT2 EXAMPLE -->
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Add Purchase</h3>

        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
            
			<div class="col-md-3">
			<input type="hidden" value="<?= base_url() ?>" id="base_url" />
			 <input type="hidden" id="brand_category" name="category" />
			<div class="form-group">
               <label>Date</label>
			   <input type="date" name="date" class="form-control" placeholder="Date" />
			   <span style="color:red"><?= form_error("date")?></span>
			 </div>
			</div>
			
			<div class="col-md-3">
				<div class="form-group">
					<label>Supplier Name</label>
				   <input type="text" id="suppliername" name="suppliername" class="form-control" placeholder="Supplier Name" />
					 <span style="color:red"><?= form_error("suppliername")?></span>
				</div>
			</div>
			
			<div class="col-md-3">
				<div class="form-group">
			    <label>Select Product</label>
				<select class="form-control select2" name="productID" id="brand_productID" style="width: 100%;">
					<option value="">Select Product</option>
					<?php 
					foreach($products as $product){
					?>
						<option data-category="<?= $product["ProductCategory"]?>" value="<?= $product['ProductID']?>"><?= $product["ProductName"]; ?></option>
       			<?php } ?>
		        </select>
					 <span style="color:red"><?= form_error("productID")?></span>
              </div>
			</div>

			<div class="col-md-3">
			  <div class="form-group" id="purchase_brand">
					<label>Select Brand</label>
					<select class='form-control select2' id='brandID' name="brandID" data-placeholder="Select Brand" name='brands[]' style='width: 100%'>
						<option value="">Select Brand</option>
						<?php 
							foreach($brands as $brand){
							?>
								<option value="<?= $brand['BrandID']?>"><?= $brand["BrandName"]; ?></option>
						<?php } ?>
					</select>
						<span style="color:red"><?= form_error("brandID")?></span>
			  </div>
			</div>
			 </div>
			<div class="row">		
			<div class="col-md-3">	
			 <div class="form-group">
					<label>Description</label>
					<textarea style="resize:none;" class="form-control" name="description">
					</textarea>
			  </div>
			</div>
			
			<div class="col-md-3">
			<div class="form-group">
                <label>Select Count</label>
          
				<select class="form-control select2" name="countID" style="width: 100%;">
                        <option value="">Select Count</option>
				  <?php 
					foreach($counts as $count){
					?>
						<option value="<?= $count['CountsID']?>"><?= $count["CountName"]; ?></option>
       			<?php } ?>
                </select>
					 <span style="color:red"><?= form_error("countID")?></span>
              </div>
			</div>
			
			<div class="col-md-3">
			<div class="form-group" style="display:none;" id="colours_box">
                <label>Colour</label>
			  	
				<select class="form-control select2" data-placeholder="Select Colour" name="colourID" id="colourID" style="width: 100%;">
					<?php 
					foreach($colours as $colour){
					?>
						<option value="<?= $colour['ColourID']?>"><?= $colour["ColourName"]; ?></option>
       			<?php } ?>
		        </select>
				<span style="color:red"><?= form_error("colourID")?></span>
			   </div>
			</div>   
			
			<div class="col-md-3">			
			<div class="form-group" style="display:none;" id="chemicals_box">
                <label>Chemicals</label>
			  	
				<select class="form-control select2" data-placeholder="Select Chemicals" name="chemicalID" id="chemicalID" style="width: 100%;">
					<?php 
					foreach($chemicals as $chemical){
					?>
						<option value="<?= $chemical['ChemicalID']?>"><?= $chemical["ChemicalName"]; ?></option>
       			<?php } ?>
	
				</select>
				<span style="color:red"><?= form_error("ChemicalID")?></span>
			   </div> 
			</div>
			</div>
			
			<div class="row">
			<div class="col-md-3">
			<div class="form-group">
                <label>Unit</label>
				
				<select class="form-control select2" name="unitID" id="purchase_unit" style="width: 100%;">
					<option value="">Select Unit</option>
					<?php 
					foreach($units as $unit){
					?>
						<option value="<?= $unit['UnitID']?>"><?= $unit["UnitName"]; ?></option>
       			<?php } ?>
		        
</select>
<span style="color:red"><?= form_error("unitID")?></span>
			</div>
			</div>
			
			<div class="col-md-3">
				<div class="form-group">
					<label>Quantity</label>
				   <input type="text" id="purchase_quantity" name="quantity" class="form-control" placeholder="Quantity" />
					 <span style="color:red"><?= form_error("quantity")?></span>
				</div>
			</div>
			
			<div class="col-md-3">
				<div class="form-group">
					<label>Rate</label>
				   <input type="text" id="purchase_rate" name="rate" class="form-control" placeholder="Rate" />
					 <span style="color:red"><?= form_error("rate")?></span>
				</div>
			</div>
			
		<div class="col-md-3">			
			<div class="form-group">
                <label>Quantity Bundle</label>
			   <input type="text" readonly id="purchase_quantity_bundle" name="quantity_bundle" class="form-control" placeholder="Quantity Bundle" />
			   	 <span style="color:red"><?= form_error("quantity_bundle")?></span>
			   </div>
			</div></div>
		</div>
            <!-- /.col -->
            
            <!-- /.col -->
         
        <div class="box-footer">
		<button type="submit" class="btn btn-primary pull-right">Submit</button>
		</div>
       
        </div>
        </form>
		</div>
		
	  <!-- Purchasing End -->
	  <?php
		$error_check = $this->session->flashdata("recieve_error");
		$date = $this->session->flashdata("date");
		$productID = $this->session->flashdata("productID");
		$brandID = $this->session->flashdata("brandID");
		$partyID = $this->session->flashdata("partyID");
		$countID = $this->session->flashdata("countID");
		$quantity = $this->session->flashdata("quantity");
		$quantity_bundle = $this->session->flashdata("quantity_bundle");
		$unitID = $this->session->flashdata("unitID");
		
	  ?>
	  <div id="recieve_box" style="display:<?= ($error_check == "1" ? "block" : "none")?>">
      <form method="post" action="<?= base_url("recieving/save")?>">
		<div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Add Recieve</h3>

        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
            <div class="col-md-3">
			<input type="hidden" value="<?= base_url() ?>" id="base_url" />
			

			<div class="form-group">
               <label>Date</label>
			   <input type="date" name="date" class="form-control" placeholder="Date" />
			   <span style="color:red"><?= $date ?></span>
			   </div>
			</div>
		
		
		<div class="col-lg-3">	
			<div class="form-group">
                <input type="hidden" id="category" name="category" />
				<label>Select Party</label>
			    <select class="form-control select2" id="partyID" name="partyID" style="width: 100%;">
					<option value="">Select Party</option>
					<?php 
						foreach($parties as $party){
					?>
						<option value="<?= $party['PartyID']?>"><?= $party["PartyName"]; ?></option>
       			<?php } ?>
		        </select>
					 <span style="color:red"><?= $partyID ?></span>
              </div>
		  </div>
		  
		  <div class="col-lg-3">	
			<div class="form-group">
                <label>Select Product</label>
				<select class="form-control select2" name="productID" id="productID" style="width: 100%;">
					     <option value="">Select Product</option>
					<?php 
					foreach($products as $product){
					?>
						<option data-category="<?= $product["ProductCategory"]?>" value="<?= $product['ProductID']?>"><?= $product["ProductName"]; ?></option>
       			<?php } ?>
		        </select>
					 <span style="color:red"><?= $productID ?></span>
              </div>
			</div>
			
			<div class="col-lg-3">	

			  <div class="form-group" id="reference_box">
					<label>Select Brand</label>
					<select class='form-control select2' id='brandID' name="brandID" data-placeholder="Select Brand" name='brands[]' style='width: 100%'>
						<option value="">Select Brand</option>
						<?php 
							foreach($brands as $brand){
							?>
								<option value="<?= $brand['BrandID']?>"><?= $brand["BrandName"]; ?></option>
						<?php } ?>
					</select>
					 <span style="color:red"><?= $brandID ?></span>
			  </div>
			</div>
			
			</div>
			
			<div class="row">
			
			<div class="col-lg-3">	
				<div class="form-group">
					<label>Description</label>
					<textarea style="resize:none;" class="form-control" name="description">
					</textarea>
			  </div>
			</div>
			
			<div class="col-lg-3">	
				<div class="form-group">
                <label>Select Count</label>
           
				<select class="form-control select2" name="countID" style="width: 100%;">
                       <option value="">Select Count</option>
				  <?php 
					foreach($counts as $count){
					?>
						<option value="<?= $count['CountsID']?>"><?= $count["CountName"]; ?></option>
       			<?php } ?>
                </select>
					 <span style="color:red"><?= $countID ?></span>
              </div>
			</div>
		<!--  	<div class="form-group" style="display:none;" id="colours_box">
                <label>Colour</label>
			  	
				<select class="form-control select2" data-placeholder="Select Colours" multiple name="colourID[]" id="colourID" style="width: 100%;">
					<?php 
					foreach($colours as $colour){
					?>
						<option value="<?= $colour['ColourID']?>"><?= $colour["ColourName"]; ?></option>
       			<?php } ?>
		        </select>
				<span style="color:red"><?= form_error("colourID")?></span>
			</div> -->
			   
			  
			<!-- <div class="form-group" style="display:none;" id="chemicals_box">
                <label>Chemicals</label>
			  	
				<select class="form-control select2" data-placeholder="Select Chemicals" multiple name="chemicalID[]" id="chemicalID" style="width: 100%;">
					<?php 
					foreach($chemicals as $chemical){
					?>
						<option value="<?= $chemical['ChemicalID']?>"><?= $chemical["ChemicalName"]; ?></option>
       			<?php } ?>
	
				</select>
				<span style="color:red"><?= form_error("colourID")?></span>
			   </div>  -->
			
			<div class="col-lg-2">
			<div class="form-group">
                <label>Unit</label>
				<select class="form-control select2" name="unitID" id="unit" style="width: 100%;">
					<option value="">Select Unit</option>
					<?php 
					foreach($units as $unit){
					?>
						<option value="<?= $unit['UnitID']?>"><?= $unit["UnitName"]; ?></option>
       			<?php } ?>
		        
				</select>
					<span style="color:red"><?= $unitID ?></span>
			
			</div>
			</div>
			
			
			<div class="col-lg-2">
			<div class="form-group">
                <label>Quantity</label>
			   <input type="text" id="quantity" name="quantity" class="form-control" placeholder="Quantity" />
			   	 <span style="color:red"><?= $quantity ?></span>
			</div>
			</div>
			
			<div class="col-lg-2">
			<div class="form-group">
                <label>Quantity Bundle</label>
			   <input type="text" value="0" readonly id="quantity_bundle" name="quantity_bundle" class="form-control" placeholder="Quantity Bundle" />
			   	 <span style="color:red"><?= $quantity_bundle?></span>
			   </div>
			</div>
			
			</div>
			
			
		
            <!-- /.col -->
            
            <!-- /.col -->
        
          <!-- /.row -->
        </div>
		<div class="box-footer">
		<button type="submit" class="btn btn-primary pull-right">Submit</button>
		</div>
      </div>
	</form>
		</div>
    </section>
	  <!-- /.content -->
  </div>
  
 
	<?= include(APPPATH."views/includes/footer.php"); ?>
  
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?= base_url("assets/")?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?= base_url("assets/")?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="<?= base_url("assets/")?>bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- InputMask -->
<script src="<?= base_url("assets/")?>plugins/input-mask/jquery.inputmask.js"></script>
<script src="<?= base_url("assets/")?>plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="<?= base_url("assets/")?>plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- date-range-picker -->
<script src="<?= base_url("assets/")?>bower_components/moment/min/moment.min.js"></script>
<script src="<?= base_url("assets/")?>bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- bootstrap datepicker -->
<script src="<?= base_url("assets/")?>bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- bootstrap color picker -->
<script src="<?= base_url("assets/")?>bower_components/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="<?= base_url("assets/")?>plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll -->
<script src="<?= base_url("assets/")?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="<?= base_url("assets/")?>plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="<?= base_url("assets/")?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url("assets/")?>dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?= base_url("assets/")?>dist/js/demo.js"></script>

<script src="<?= base_url("assets/")?>custom/purchasing.js"></script>

<script src="<?= base_url("assets/")?>custom/recieving.js"></script>
<!-- Page script -->
<script>
	
	
	
	$("#btn_purchase").click(function (){
		$("#purchasing_box").show();
		$("#recieve_box").hide();
	});
$("#btn_recieve").click(function (){
		$("#purchasing_box").hide();
		$("#recieve_box").show();
	});



$(document).on("keyup","#quantity", function(){
	//alert("test");
	//var selected_text = $("#unit option:selected").text();
	var selected_text = $("#productID option:selected").text();
	if(selected_text.toLowerCase() == "thread"){
		var quantity  = $(this).val();
		var bundle = quantity / 4.5;
		$("#quantity_bundle").val(bundle);
	}
	else{
		$("#quantity_bundle").val("0")
	}
	
});
	
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({ timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A' })
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass   : 'iradio_minimal-red'
    })
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  })
</script>
</body>
</html>
