<?php
		
		require_once "application/core/AdminController.php";
		class Labours extends AdminController{

			function __construct(){
				parent::__construct();
				$this->load->model("Labours_Model","labours"); 
			}
			
			function index(){
				$data["labours"] = $this->labours->read();
				$this->load->view("labours/view",$data);
			}
			
			function add(){
				$this->load->view("labours/add");
			}
			
			function save(){
				
				$this->form_validation->set_rules("name","Name","required");
				
				if($this->form_validation->run()==TRUE){
				
				$data=array(
					"LabourName"	=> $_POST["name"]
				);

				$result = $this->labours->save($data);
					
				
					if($result){
						$this->session->set_flashdata("success_msg", 
						"Labour Added Successfully!");
						redirect(base_url("labours"));
					}	
				}
			
				else{
					$this->add();
				}
			}
		
			
			function delete($id){
				
				
					$msg = "Data Deleted Successfully!";
					$msg_type = "success_msg";
					$result= $this->labours->delete($id);					
				
				                        
				$this->session->set_flashdata($msg_type, $msg);
				redirect(base_url("labours"));
				
			}
			
			function edit($id){
				$data['labours'] = $this->labours->select($id);
				$this->load->view("labours/edit",$data);
				
			}
			
			function update($id){
				
				$this->form_validation->set_rules("name","Name","required");
				
				if($this->form_validation->run()==TRUE){
				
				$data=array(
					"LabourName"	=> $_POST["name"]
				);
			
				$result = $this->labours->update($id,$data);
				if($result){
					$this->session->set_flashdata("success_msg", "Labour Updated Successfully!");
					redirect(base_url("labours"));
				}	
			}
			
			else{
				$this->edit($id);
			}
			
		}
		
		
			
	}	
?>