$(document).on("change","#brand_productID", function (){
	
	var productID = $("#brand_productID").val();
	var base_url = $("#base_url").val();
	
	var category = $(this).find(':selected').data("category");
	
	if(category == "dyes"){
		$("#colours_box").show();
		$("#chemicals_box").hide();
		$("#brand_category").val(category);
		$("#chemical_select").removeAttr("name");
		$("#chemical_select").attr("name","colourID");
	
	}else if(category == "chemical"){
		$("#colours_box").hide();
		$("#chemicals_box").show();
		$("#brand_category").val(category);	
		$("#color_select").removeAttr("name");
		$("#chemical_select").attr("name","chemicalID");
	}else if(category == "other"){
		$("#colours_box").hide();
		$("#chemicals_box").hide();
		$("#brand_category").val(category);	
		$("#color_select").removeAttr("name");
		$("#chemical_select").removeAttr("name","chemicalID");
	}
	
	
	// $.ajax({
		// url:base_url+"purchasing/brands_relateds_products",
		// method:"post",
		// data:{productID:productID},
		// success:function (result){
			// $("#purchase_brandID").append("");
			// $("#purchase_brand").show();
			// $("#purchase_brandID").append(result);
		// }
	// });
});

