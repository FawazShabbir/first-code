<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin | Purchase Details</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  
  <?= include(APPPATH."views/includes/header.php"); ?>
  <?= include(APPPATH."views/includes/sidebar.php"); ?>
  
  <!-- Left side column. contains the logo and sidebar -->
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Invoice
        <small>#<?= $purchase[0]["PurchaseID"]?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Purchase</a></li>
        <li class="active">Details</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
            <i class="fa fa-user"></i> Supplier Name : <?= $purchase[0]["SupplierName"]?>
            <small class="pull-right">Date: <?= $purchase[0]["Date"]?></small>
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->
      <div class="row invoice-info">
       <div   class="col-lg-2 invoice-col">
		</div>
	   <div style="font-size:16px;"  class="col-lg-8 invoice-col">
			<center> <h3> Voucher No. <b>#<?= $purchase[0]["PurchaseID"]?></b> </h3> </center>
			<table class="table table-bordered">
				<tbody>  
					<tr>
						<th> Purchase Date </th>
						<td>  <?= date("d-M-Y", strtotime($purchase[0]["PurchaseDate"]))?> </td>
					</tr>
					<tr>
						<th> Product </th>
						<td>  <?= $purchase[0]["ProductName"]?> </td>
					</tr>
					<tr>
						<th> Brand </th>
						<td>  <?= $purchase[0]["BrandName"]?> </td>
					</tr>
					<?php
						if($purchase[0]["ColourID"]!=null){
					?>
					
					<tr>
						<th> Colour </th>
						<td>  <?= $purchase[0]["ColourName"]?> </td>
					</tr>
						<?php } ?>
					<?php
						if($purchase[0]["ChemicalID"]!=null){
					?>
					<tr>
						<th> Chemical </th>
						<td>  <?= $purchase[0]["ChemicalName"]?> </td>
					</tr>
					<?php } ?>
					<tr>
						<th> Unit </th>
						<td>  <?= $purchase[0]["UnitName"]?> </td>
					</tr>
					<tr>
						<th> Quantity </th>
						<td>  <?= $purchase[0]["Qtyinkg"]?> </td>
					</tr>
					<tr>
						<th> Rate </th>
						<td>  <?= $purchase[0]["Rate"]?> </td>
					</tr>
					<tr>
						<th> Description </th>
						<td>  <?= $purchase[0]["Description"]?> </td>
					</tr>
				</tbody>
			</table>
		</div>
		<div style="font-size:18px;"  class="col-lg-2 invoice-col">
		</div>
	   
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Table row -->
     
      <br>
      <!-- this row will not appear when printing -->
      
    </section>
    <!-- /.content -->
    <div class="clearfix"></div>
  </div>
  
  <div class="no-print">
  <?= include(APPPATH."views/includes/footer.php"); ?>
  </div>
  
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?= base_url("assets/")?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?= base_url("assets/")?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?= base_url("assets/")?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url("assets/")?>dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?= base_url("assets/")?>dist/js/demo.js"></script>
</body>
</html>
