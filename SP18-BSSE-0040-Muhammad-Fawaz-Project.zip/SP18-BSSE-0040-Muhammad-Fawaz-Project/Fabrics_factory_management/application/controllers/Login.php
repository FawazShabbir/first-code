<?php
//defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	
	public function __construct(){
		parent::__construct();
		
		
		$this->load->model("Admin_model");
	}

	public function index()
	{
		$userID = $this->session->userdata("User_ID");
		if(!isset($userID)){
			$this->load->view('login');	
		}else{
			redirect(base_url("dashboard"));
		}
		
	}
	

	function signin(){
		
		$this->form_validation->set_rules("email","Email","required|strtolower");
		$this->form_validation->set_rules("password","Password","required");
		
		if($this->form_validation->run()==TRUE){
		
			$email = $this->input->post("email");
			$password = $this->input->post("password");
			$result = $this->Admin_model->signin($email);
			
			if(count($result)!=0){
			 $decrypt = $this->$result[0]['Password'];
				if($password === "admin"){

					// Setting Values in Session
					$this->session->set_userdata("User_ID",$result[0]["UserID"]);
					$this->session->set_userdata("User_Firstname",$result[0]["Username"]);
					redirect(base_url("dashboard"));
				}	
				else{
					$this->session->set_flashdata("Wrong_credentials",'<div class="alert alert-warning" role="alert"><strong>Alert !</strong> Username or Password is Incorrect. </div>');
					redirect(base_url());
				}
			}
			else{
				$this->session->set_flashdata("Wrong_credentials",'<div class="alert alert-warning" role="alert"><strong>Alert!</strong> Username or Password is Incorrect. </div>');
				redirect(base_url());
			}
		}
		else{
			// Form Error in Flashdata
			$this->session->set_flashdata([
				"err_login_email" => form_error("email"),
				"err_login_password" => form_error("password")
				]);
			
			// Form Values when validations not match
			$this->session->set_flashdata([
				"login_email" => set_value("email"),
				"login_password" => set_value("password")
				
			]);
			redirect(base_url());
		}	
	}
}
