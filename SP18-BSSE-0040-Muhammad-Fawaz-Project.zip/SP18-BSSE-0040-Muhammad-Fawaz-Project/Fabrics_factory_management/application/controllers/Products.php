<?php
		
		require_once "application/core/AdminController.php";
		class Products extends AdminController{

			function __construct(){
				
				parent::__construct();
				$this->load->model("Product_model","products"); 
				$this->load->model("Brands_model","brands"); 
			
			}
			
			function index(){
	            $data["products"] = $this->products->read();
				$this->load->view("products/view",$data);
				
			}
			
			function add(){
				
				$data["chemical"] = $this->products->read_chemicals();
				$data["colour"] = $this->products->read_colours();
				$data["brands"] = $this->brands->read();
				$this->load->view("products/add",$data);
			}
			
			function save(){
					
				$this->form_validation->set_rules("name","Name","required");
				//$this->form_validation->set_rules("brandIDs","Brand","required");
				$this->form_validation->set_rules("category","Category","required");
//				$this->form_validation->set_rules("colours","Colours","required");
				
				if($this->form_validation->run()==TRUE){
				
    				$data=array(
    					"ProductName"	=> 	$_POST["name"],
    					"ProductCategory" 	=> $_POST['category'],
    					"Date" 			=>	date("d-M-y"),
    					"Month" 		=>	date("m"),
    					"Year" 			=>	date("Y")
    				);	
				
				// Insert into Products Tab
				$result = $this->products->save($data);
				
				$this->session->set_flashdata("success_msg", "Product Added Successfully!");
				redirect(base_url("products"));
			}
			
				else{
					$this->add();
				}
			}
		
			
			function delete($id){
				
				
				$msg = "";
				$msg_type = "";
				
					$msg = "Data Deleted Successfully!";
					$msg_type = "success_msg";
					$success = $this->products->delete($id);                        
				
				                        
				$this->session->set_flashdata($msg_type, $msg);
				redirect(base_url("products"));
			}
			
			function edit($id){
				$data['product'] = $this->products->select($id);
				$this->load->view("products/edit",$data);
			
			}

			
			function update($id){
				
				$this->form_validation->set_rules("name","Name","required");
				$this->form_validation->set_rules("category","Category Name","required");
				
				if($this->form_validation->run()==TRUE){
				
					$data=array(
					"ProductName"	=> 	$_POST["name"],
					"ProductCategory"  => $_POST['category'],
					"Date" 			=>	date("d-M-y"),
					"Month" 		=>	date("m"),
					"Year" 			=>	date("Y")
				);	
				$result = $this->products->update($id,$data);
				
				$this->session->set_flashdata("success_msg", "Product Updated Successfully!");
				redirect(base_url("products"));
					
			}
			
			else{
				$this->edit($id);
			}
			
		}
		
		
		
		/* Getting Brands of Products */
			
		function brands_of_products(){
			$data = []; 
				foreach($this->products->read() as $products){
					$data["products"][] = array(
						"ProductID"	  => $products["ProductID"],
						"ProductName" => $products["ProductName"],
						"ProductCategory"	=> $products["ProductCategory"],
						"Brands"	=>	$this->products->brands_of_products($products["ProductID"])
					);
			}
		
			return $data;
		}
		
		
	}	
?>