<?php
		
		require_once "application/core/AdminController.php";
		class Units extends AdminController{

			function __construct(){
				parent::__construct();
				$this->load->model("Units_Model","units"); 
			}
			
			function index(){
				$data["units"] = $this->units->read();
				$this->load->view("units/view",$data);
			}
			
			function add(){
				$this->load->view("units/add");
			}
			
			function save(){
				
				$this->form_validation->set_rules("unitname","Units","required");
				
				if($this->form_validation->run()==TRUE){
				
				$data=array(
					"UnitName"		=> 	$_POST["unitname"]
				);

				$result = $this->units->save($data);
					
				
					if($result){
						$this->session->set_flashdata("success_msg", "Units Added Successfully!");
						redirect(base_url("units"));
					}	
				}
			
				else{
					$this->add();
				}
			}
		
			
			function delete($id){
		
				
				
				
					$msg = "Data Deleted Successfully!";
					$msg_type = "success_msg";
					$result= $this->units->delete($id);
			
				
				                        
				$this->session->set_flashdata($msg_type, $msg);
				redirect(base_url("units"));
			}
			
				
			function edit($id){
				$data['units'] = $this->units->select($id);
				$this->load->view("units/edit",$data);
			}

			
			function update($id){
				
				$this->form_validation->set_rules("unitname","Units","required");
				
				if($this->form_validation->run()==TRUE){
				
				$data=array(
					"UnitName"		=> 	$_POST["unitname"]
				);
			
				$result = $this->units->update($id,$data);
				if($result){
					$this->session->set_flashdata("success_msg", "Units Updated Successfully!");
					redirect(base_url("units"));
				}	
			}
			
			else{
				$this->edit($id);
			}
			
		}
		
			
	}	
?>