
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Edit Units</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>dist/css/skins/_all-skins.min.css">

 
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
	
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

 <?php include(APPPATH.'views/includes/header.php'); ?>
 
 <?php include(APPPATH.'views/includes/sidebar.php'); ?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Units</a></li>
        <li class="active">Edit Units</li>
      </ol>
    </section>

	<form action="<?= base_url("units/")?>update/<?= $units[0]["UnitID"]?>" method="post">
    <!-- Main content -->
    <section class="content">

				<div class="container">
				<div class="row">
				<div class="col-lg-6 col-lg-offset-2">
				
			
      <!-- SELECT2 EXAMPLE -->
      <div class="box box-default">
		<div class="box-header with-border">
		  <h1 class="box-title" style="font-size:24px;">Edit Units</h1>
		</div>
        <!-- /.box-header -->
		
		
        <div class="box-body">
          
		  <div class="row">
        	
			<div class="col-md-12">
			  
			   <div class="form-group">
                <label>Units:</label>
                <input value="<?= $units[0]["UnitName"]; ?>" type="text" name="unitname" placeholder="Units" class="form-control" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABHklEQVQ4EaVTO26DQBD1ohQWaS2lg9JybZ+AK7hNwx2oIoVf4UPQ0Lj1FdKktevIpel8AKNUkDcWMxpgSaIEaTVv3sx7uztiTdu2s/98DywOw3Dued4Who/M2aIx5lZV1aEsy0+qiwHELyi+Ytl0PQ69SxAxkWIA4RMRTdNsKE59juMcuZd6xIAFeZ6fGCdJ8kY4y7KAuTRNGd7jyEBXsdOPE3a0QGPsniOnnYMO67LgSQN9T41F2QGrQRRFCwyzoIF2qyBuKKbcOgPXdVeY9rMWgNsjf9ccYesJhk3f5dYT1HX9gR0LLQR30TnjkUEcx2uIuS4RnI+aj6sJR0AM8AaumPaM/rRehyWhXqbFAA9kh3/8/NvHxAYGAsZ/il8IalkCLBfNVAAAAABJRU5ErkJggg==&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%; cursor: auto;">
                <span style="color:red"><?= form_error("unitname"); ?></span>
			  </div>
	        </div>
			
			
          </div>
          <!-- /.row -->
        </div>
      
	  <div class="box-footer">
			<button type="submit" class="btn btn-primary pull-right">Update</button>
			</div>
	  </div>
	         <!-- /.box -->
 <!-- /.row -->
</div>
</div>
</div>
    </section>
	</form>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 
 <?php include(APPPATH.'views/includes/footer.php'); ?>
 
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?= base_url("assets/")?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?= base_url("assets/")?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?= base_url("assets/")?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url("assets/")?>dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?= base_url("assets/")?>dist/js/demo.js"></script>
</body>
</html>
