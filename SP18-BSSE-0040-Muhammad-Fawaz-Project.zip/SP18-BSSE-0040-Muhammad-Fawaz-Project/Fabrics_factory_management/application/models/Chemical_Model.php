<?php
	
	class Chemical_model extends CI_MODEL{
		
		function read(){
			$result = $this->db->get("chemicals");
			return $result->result_array();
		}
		
		function select($id){
			$this->db->where("ChemicalID",$id);
			$result = $this->db->get("chemicals");
			return $result->result_array();
		}
	
		function save($data){
			$result = $this->db->insert("chemicals",$data);
			return $result;
		}
		
		function delete($id){
			$this->db->where("ChemicalID",$id);
			$result = $this->db->delete("chemicals");
			return $this->db->error();
		}
		
		function update($id,$data){
			$this->db->where("ChemicalID",$id);
			$result = $this->db->update("chemicals",$data);
			return $result;
		}
			
			
		
		
	}

?>
