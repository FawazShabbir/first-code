
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?= base_url()?>assets/img/user.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?= $this->session->userdata("User_Firstname"); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
     
	 <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        
        <li>
		  <a href="<?= base_url("dashboard")?>">
            <i class="fa fa-tachometer"></i> <span>Dashboard</span>
            <span class="pull-right-container">
            </span>
          </a>
        </li>
		
		<li class="treeview">
          <a href="#">
            <i class="fa fa-product-hunt"></i> <span>Products</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
        
		<ul class="treeview-menu">
			<li><a href="<?= base_url("brands")?>"><i class="fa fa-circle-o"></i>Brands</a></li>
            <li><a href="<?= base_url("chemicals")?>"><i class="fa fa-flask"></i>Chemicals</a></li>
            <li><a href="<?= base_url("colours")?>"><i class="fa fa-circle-o"></i>Colors</a></li>
            <li><a href="<?= base_url("units")?>"><i class="fa fa-circle-o"></i>Units</a></li>
			<li><a href="<?= base_url("products")?>"><i class="fa fa-circle-o"></i>Products</a></li>
        </ul>
       </li>

		
		<li>
		  <a href="<?= base_url("supplier")?>">
            <i class="fa fa-users"></i> <span>Suppliers</span>
            <span class="pull-right-container">
            </span>
          </a>
        </li>
		
		<li>
		  <a href="<?= base_url("labours")?>">
            <i class="fa fa-user"></i> <span>Labours</span>
            <span class="pull-right-container">
            </span>
          </a>
        </li>
	
		<li>
          <a href="<?= base_url("purchasing")?>">
            <i class="fa fa-get-pocket"></i> <span>Purchasing</span>
               <span class="pull-right-container">
            </span>
          </a>
		  
		</li>
		
			
	

		
		
		
		<li>
          <a href="<?= base_url("dashboard/logout"); ?>">
            <i class="fa fa-sign-out"></i> <span>Logout</span>
            <span class="pull-right-container">
            </span>
          </a>
        </li>
		
	  </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
