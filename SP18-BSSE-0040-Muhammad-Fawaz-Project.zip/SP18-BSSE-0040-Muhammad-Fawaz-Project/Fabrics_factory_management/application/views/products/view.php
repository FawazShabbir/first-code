<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin | Products</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?= base_url("assets/")?>dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
	
	<?php include(APPPATH.'views/includes/header.php'); ?>
	<?php include(APPPATH.'views/includes/sidebar.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Products
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li	><a href="#">Products</a></li>
        <li class="active">View</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
		      <?php
				$success = $this->session->flashdata("success_msg");
				if(isset($success)){
			 ?>
			<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i>Success!</h4>
                <?= $success; ?>
              </div>
			<?php } ?>		
			
				<?php
				$danger = $this->session->flashdata("danger_msg");
				if(isset($danger)){
			 ?>
			<div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-ban"></i>Error!</h4>
                <?= $danger; ?>
              </div>
			<?php } ?>		
			
			
           <div class="box-header">
              <h3 class="box-title">Products</h3>
			   <a href="<?= base_url("products/add")?>" style="float:right; margin:10px 5px;" class="btn btn-primary"><i class="fa fa-plus"></i> &nbsp; Add</a>
			</div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
				  <th>S.No</th>
                  <th>Product</th>
                  <th>Category</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
				
                 <?php
					$count = 0;
					 if(isset($products) && count($products) > 0){
						foreach($products as $product){
					$count++;
				  ?>
				<tr>
				  <td><?= $count; ?> </td>
                  <td><?= $product['ProductName']; ?></td>
                  <td><?= $product['ProductCategory']; ?></td>
                  <td>
					  <a href="<?= base_url("products/delete/".$product['ProductID'])?>" title="Delete" onclick="return confirm('Are you sure you want to delete?')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
				      
				  </td>
				</tr>
					<?php }} ?>
                </tbody>
                
                
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 
 <?php include(APPPATH.'views/includes/footer.php'); ?>

  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- Modal -->
  <div class="modal  fade" id="rate_modal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Rate</h4>
        </div>
        <div class="modal-body">
          <form method="post" action="<?= base_url("products/add_rate")?>">
            <input type="hidden" id="productID" name="ProductID">
              <div class="form-group">
                <label for="rate">Rate:</label>
                <input type="text" required class="form-control" id="rate" name="ProductRate">
              </div>
              <button type="submit" class="btn btn-primary">Add Rate</button>
            </form>
        </div>
        <div class="modal-footer">
          
        </div>
      </div>
      
    </div>
  </div>
  
  
  

  


<!-- jQuery 3 -->
<script src="<?= base_url("assets/")?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?= base_url("assets/")?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?= base_url("assets/")?>bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url("assets/")?>bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?= base_url("assets/")?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?= base_url("assets/")?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url("assets/")?>dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?= base_url("assets/")?>dist/js/demo.js"></script>
<!-- page script -->
<script>


    $(document).on('click','.btn_rate', function (){
       var id=$(this).data("id");
       $("#productID").val(id);
    });

    $(document).on('click','.edit_rate', function (){
       var id=$(this).data("id");
       var rate = $(this).data("rate");
       $("#edit_productID").val(id);
       $("#edit_productrate").val(rate);
    });

  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
</body>
</html>
